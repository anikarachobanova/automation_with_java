public interface IЕlectronicDevice {
    void start ();
    void stop ();
    boolean isStarted();

}
