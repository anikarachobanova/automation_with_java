//Да се създаде UserImpl клас, който е User(AbstractUser).
public class UserImpl extends AbstractUser{
    UserImpl (String username){
        super(username);

    }


}
